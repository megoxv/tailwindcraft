This is where language files should be placed.

Please DO NOT trangray these directly use this service: https://www.transifex.com/projects/p/tinymce/
