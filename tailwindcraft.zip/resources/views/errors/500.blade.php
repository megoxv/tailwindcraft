@extends('errors::minimal')

@section('title', __('main.server_error'))
@section('code', '500')
@section('message', __('main.server_error'))
