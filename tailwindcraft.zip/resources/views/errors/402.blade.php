@extends('errors::minimal')

@section('title', __('main.payment_required'))
@section('code', '402')
@section('message', __('main.payment_required'))
