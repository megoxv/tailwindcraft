@extends('errors::minimal')

@section('title', __('main.page_expired'))
@section('code', '419')
@section('message', __('main.page_expired'))
