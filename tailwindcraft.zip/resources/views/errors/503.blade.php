@extends('errors::minimal')

@section('title', __('main.service_unavailable'))
@section('code', '503')
@section('message', __('main.service_unavailable'))
