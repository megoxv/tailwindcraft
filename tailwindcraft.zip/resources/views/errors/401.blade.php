@extends('errors::minimal')

@section('title', __('main.unauthorized'))
@section('code', '401')
@section('message', __('main.unauthorized'))
