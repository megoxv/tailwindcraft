@extends('errors::minimal')

@section('title', __('main.not_found'))
@section('code', '404')
@section('message', __('main.sorry,_we_couldn\'t_find your_page'))
