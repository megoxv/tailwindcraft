<?php

return [
    "pattern_name" => [
        "search" => "",
        "replace" => "",
        // "post_replace" => ""
    ],
];
